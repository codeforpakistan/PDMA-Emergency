<?php 
$str = "allaudin qazi";
echo str_replace("qazi", "muha", $str);
