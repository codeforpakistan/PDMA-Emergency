<?php

/*
Plugin Name: CatIcon
Plugin URI: http://categoryicon.com
Version: 0.0.1
Author: M.Allaudin
Author URI: http://mallaudin.com
License: GPLv2 or later
Description: Simple plugin for attaching icons with category
*/


register_activation_hook( __FILE__, 'activate' );

function activate(){
  add_option( 'cat_icon', array());
}

add_action( 'admin_enqueue_scripts', 'admin_scripts');

function admin_scripts() {
  wp_register_script( 'cat_icon', plugins_url( 'cat_icon.js', __FILE__ ), array(), '0.0.1', true );
  if ( isset($_GET['taxonomy']) ) {
    wp_enqueue_media();
    wp_enqueue_script('cat_icon');
  }
} // end admin_scripts


add_action("admin_init", "tpn_admin_init");

function tpn_admin_init(){
  register_setting( 'tpn_cat_icons', 'cat_icon', 'sanitize_cat_icon_path');
}

function sanitize_cat_icon_path( $input ){
  global $wpdb;
  $icon = [];

  $myfile = fopen(plugin_dir_path( __FILE__ ) . "deb.txt", "w");
  fwrite($myfile, json_encode($input));

  if ( isset($input['id']) ) {
    $icon["cat_{$input['id']}"] = substr($input['url'],strpos($input['url'], "uploads") + 7 );
  
  }else {

      if( isset( $input['name'] ) ) {

        if ( !isset($input['slug'] ) || (strlen( $input['slug'] ) == 0) )
          $input['slug'] = implode("-", explode(" ", $input['name'])); 

      $qur = "SELECT term_id FROM wp_terms WHERE " .
              " name = '" .  $input['name'] . 
              "' and slug = '" . strtolower($input['slug']) ."'";

      $cat_id = $wpdb->get_var( $qur );

       if ( $cat_id != null ){
        $icon["cat_{$cat_id}"] = substr($input['url'],strpos($input['url'], "uploads") + 7 );
         fwrite($myfile, $input['url']);
      }

    } // end check name 

  } // end if else   
  $old = get_option('cat_icon');
  if ( isset($old) && is_array($old) && !empty($old) ) $icon = array_merge($old, $icon);
  return $icon;

} // end sanitize_cat_icon_path


// add_action('category_edit_form_fields','category_edit_form_fields');
add_action('category_edit_form', 'category_edit_form');
add_action('category_add_form_fields','category_add_form_fields');
// add_action('category_add_form','category_add_form');

function category_add_form_fields(){
  require( plugin_dir_path( __FILE__ ) . "cat_form.php" ); ?>
  <div class="form-field">
    <label for="icon">Icon</label>
    <img src="<?php echo $cat_icon; ?>" id="icon" 
      style="
      width: 26px; 
      height: 26px; 
      margin-right: 42px; 
      border-radius: 50%;
      background-position: center center;
      background-size: cover;">
      <input type="hidden" name="cat_icon[name]" value="" />
      <input type="hidden" name="cat_icon[slug]" value="" />
      <input type="hidden" name="cat_icon[url]" value="" id="icon_input"/>
      <input type="button" id="icon_select" name="btn" value="Browse Icon" class="button action" />
      <p class="description">Attach icon with category</p>
  </div>
<?php }

function category_edit_form() {
  require( plugin_dir_path( __FILE__ ) . "cat_form.php" ); ?>
  <table class="form-table">
    <th scope="row">Icon</th>
    <td>
      <img src="<?php echo $cat_icon; ?>" id="icon" 
      style="
      width: 26px; 
      height: 26px; 
      margin-right: 42px; 
      border-radius: 50%;
      background-position: center center;
      background-size: cover;">
      <input type="hidden" name="cat_icon[id]" value="<?php echo $id; ?>" />
      <input type="hidden" name="cat_icon[url]" value="<?php echo $cat_icon; ?>" id="icon_input"/>
      <input type="button" id="icon_select" name="btn" value="Browse Icon" class="button action" />
      <p class="description">Attach icon with category</p>
    </td>
  </table>
  </form>
<?php } // end category_edit_form

add_filter( 'get_category_icons', 'get_cat_icons');

function get_cat_icons() {
  
  $categories = get_categories();
  $cat_icons = get_option('cat_icon');

  foreach ($categories as $category) { ?>
    <div class="cat" title="<?php echo $category->description; ?>">
      <a href="<?php echo get_category_link($category->cat_ID); ?>">
        <img src='<?php $icon = $cat_icons["cat_{$category->term_id}"]; if(isset($icon)) echo $icon; ?>'>
        <p class="title"><?php echo $category->cat_name; ?></p>
       <span class="badge"><?php echo $category->count; ?></span>
      </a>
    </div>
<?php  } // end foreach
    
} // end get_cat_icons

add_action('delete_category', 'dclsdf');
function dclsdf( $id ) {
  $myfile = fopen(plugin_dir_path( __FILE__ ) . "deb.txt", "w");
  fwrite($myfile, "deredfd");
}