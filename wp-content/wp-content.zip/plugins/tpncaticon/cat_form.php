</form> 
<form method="post" action="options.php" id="cat_icon_form">
  <?php settings_fields('tpn_cat_icons');
      $id = $_GET['tag_ID'];
      $cat_icon = get_option('cat_icon');
      if ( is_array($cat_icon) && isset($cat_icon["cat_{$id}"])) 
        $cat_icon = wp_upload_dir()['baseurl'] . $cat_icon["cat_{$id}"];
      else $cat_icon = ""; ?>