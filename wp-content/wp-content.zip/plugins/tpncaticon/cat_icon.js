jQuery(document).ready(function($) {
  var mediaUploader; 
  var ico_url;
  var tag_name;
  var slug;

  $('#icon_select').click(function(event) {
    event.preventDefault();

    if(mediaUploader){
      mediaUploader.open();
      return;
    }

    mediaUploader = wp.media.frames.file_frame = wp.media({
      title: "Select Category Icon",
      button: { text: "Add Icon"},
      multiple: false
    });

    mediaUploader.on('select', function(){
      var attachement = mediaUploader.state().get('selection').first().toJSON();
      ico_url = attachement.url;
       $("#icon").attr('src', ico_url);   
    });
     mediaUploader.open();
  }); /* #icon select */

$('#tag-name').blur(function(event) {
  tag_name = $(this).val().trim();
});
$('#tag-slug').blur(function(event) {
  slug = $(this).val();
});
  $("#submit").on("click", function(){
    if( ico_url !== undefined )
      $("#icon_input").val(ico_url);


    if ( $('form').is("[id='addtag']") ){
    if ( (tag_name === undefined) || (tag_name.length == 0)  ) return;
       $("input[name='cat_icon[name]']").val(tag_name); 
        $("input[name='cat_icon[slug]']").val(slug); 
        $.post('edit-tags.php', $("#addtag").serialize(), function(data, textStatus, xhr) {

          $.post('options.php', $("#cat_icon_form").serialize(), function(data, textStatus, xhr) {
     
          $("ajax-response").html("Category Added Successfully");
          $('h1').after('<div id="message" class="updated notice below-h2"><p>Category added.</div>');
          setTimeout(function(){ $('#message').fadeOut(); }, 1000);

         }); 

        });
      } else {
         $("#edittag").submit();

          $.post('options.php', $("#cat_icon_form").serialize(), function(data, textStatus, xhr) {

         }); 
      }

  });



});