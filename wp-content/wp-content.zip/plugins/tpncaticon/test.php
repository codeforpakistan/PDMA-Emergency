<?php 
$str = "http://localhost:8888/wp-content/uploads/2015/12/some.jpg";
echo(substr($str,strpos($str, "uploads") + 7 ));